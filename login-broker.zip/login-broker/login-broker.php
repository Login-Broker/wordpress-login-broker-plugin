<?php

/*
Plugin Name: Login Broker
Description: Allow people to sign up and become 'Subscriber' in your Wordpress site via social logins with Google, Facebook, Apple, Microsoft, Linkedin and more.
Author: Login Broker by Gyxi
*/

require_once plugin_dir_path(__FILE__) . 'includes/wpp-functions.php';